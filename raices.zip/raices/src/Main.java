import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class Main{
 public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new holaa().setVisible(true);
        });
    }
}

